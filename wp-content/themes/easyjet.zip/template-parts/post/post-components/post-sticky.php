<?php
/**
 * Template part for displaying sticky.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Easyjet
 */

$utility          = easyjet_utility()->utility;
$sticky           = easyjet_sticky_label( false );

echo $sticky;
