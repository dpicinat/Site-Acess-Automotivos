<?php
/**
 * Template part to display Playlist-slider widget.
 *
 * @package Easyjet
 * @subpackage widgets
 */
?>
<div class="sp-slides">
	<?php $this->the_slides_view(); ?>
</div>
<div class="sp-thumbnails">
	<?php $this->the_thumbnail_view(); ?>
</div>
